import asyncio
import aiohttp
import requests


async def main():
    n = 5
    m = 6

    print("Sent", requests.get(
        f'http://localhost:5000/send?a={n}&b={m}').json())

    bool_val = True
    while bool_val:
        async with aiohttp.ClientSession() as ses:

            async with ses.get('http://localhost:5000/receive') as respns:
                rec, status_code = await respns.json(), respns.status

            print(rec)
            if status_code == 200:
                bool_val = False

asyncio.run(main())
