import requests


def main():

    while 1:
        print(requests.get('http://localhost:5001/receive').json())

        if requests.get('http://localhost:5001/receive').status_code == 200:
            getdata = requests.get('http://localhost:5001/receive')

            if getdata.status_code == 200:
                getdata = getdata.json()
                res = int(getdata['a']) + int(getdata['b'])
                send = requests.get(f'http://localhost:5001/send?result={res}')
                print(send.json())


main()
