import json
import os
from flask import Flask
from flask import request
from flask import jsonify

app = Flask(__name__)


@app.route("/receive", methods=["GET"])
def channel_in_receiver():

    getres = os.listdir('./output')
    json_res = next((x for x in getres if 'json' in x), None)
    if json_res:
        with open(f"./output/{json_res}", encoding="utf-8") as file:
            output_data = json.load(file)
        os.remove('./output/result.json')
        os.remove('./input/task.json')

        return (jsonify(output_data), 200)

    return (jsonify("......."), 202)


@app.route("/send", methods=["GET"])
def channel_in_sender():
    var_a, var_b = request.args.get("a"), request.args.get("b")

    output_data = {"a": var_a, "b": var_b}

    with open("./input/task.json", "w", encoding="utf-8") as file:
        json.dump(output_data, file, indent=4)

    return jsonify(output_data)


if __name__ == "__main__":
    app.run(debug=True, port=5000)
