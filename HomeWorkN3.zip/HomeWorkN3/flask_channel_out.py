import json
import os
from flask import Flask
from flask import request
from flask import jsonify

app = Flask(__name__)


@app.route("/receive", methods=["GET"])
def channel_out_receiver():

    load = os.listdir('./input')
    if load:
        with open("./input/task.json", encoding="utf-8") as file:
            dataoutput_data = json.load(file)

        return (jsonify(dataoutput_data), 200)

    return (jsonify("nothing available..."), 202)


@app.route("/send", methods=["GET"])
def channel_out_sender():

    output_res = request.args.get("result")
    with open('./output/result.json', 'w', encoding="utf-8") as outfile:
        outfile.write(json.dumps({"result": output_res}, indent=4))

    return jsonify({"result": output_res})


if __name__ == "__main__":
    app.run(debug=True, port=5001)
